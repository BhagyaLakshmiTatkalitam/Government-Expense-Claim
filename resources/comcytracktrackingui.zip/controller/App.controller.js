sap.ui.define(["sap/ui/core/mvc/Controller"],r=>{"use strict";return r.extend("com.cy.track.trackingui.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map