sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.cy.track.trackingui.controller.App", {
      onInit() {
      }
  });
});